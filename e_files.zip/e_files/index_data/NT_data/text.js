<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link
      rel="icon"
      href="https://www.w3schools.com/favicon.ico"
      type="image/x-icon"
    />
    <meta name="theme-color" content="#ffffff" />
    <meta
      name="description"
      content="Sorry! We can't seem to find the page you're looking for."
    />
    <title>404 - Not found | W3 Spaces</title>
    <style>
      @import url("https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,500,600,700");
      html,
      body {
        font-family: "Source Sans Pro", sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        margin: 0;
        padding: 0;
        background-color: #ffffff;
      }
      .header {
        padding: 40px 50px;
      }
      @media only screen and (max-width: 650px) {
        .header {
          padding: 40px 20px;
        }
      }
      .body {
        *zoom: 1;
        padding-top: 109px;
      }
      @media only screen and (max-width: 650px) {
        .body {
          padding: 0px;
        }
      }      
      .body:before,
      .body:after {
        display: table;
        content: "";
        line-height: 0;
      }
      .body:after {
        clear: both;
      }
      .body > .-info-text {
        float: left;
        display: block;
        width: 50%;
      }
      @media only screen and (max-width: 650px) {
        .body > .-info-text {
          width: 100%;
        }
      }
      .body > .-info-text > .-inner-wrp {
        width: 60%;
        display: block;
        margin: 0 auto;
      }
      @media only screen and (max-width: 650px) {
        .body > .-info-text > .-inner-wrp {
          width: 90%;
          padding-left: 20px;
          margin: 0;
        }
      }
      .body > .-info-text > .-inner-wrp > .-pre-headline {
        font-style: normal;
        font-weight: normal;
        font-size: 30px;
        line-height: 36px;
        display: flex;
        align-items: center;
        color: #282a35;
      }
      .body > .-info-text > .-inner-wrp > .-headline {
        font-style: normal;
        font-weight: bold;
        font-size: 36px;
        line-height: 44px;
        display: flex;
        align-items: center;
        color: #282a35;
      }
      .body > .-info-text > .-inner-wrp > .-post-headline,
      .body > .-info-text > .-inner-wrp > .-details {
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 21px;
        color: #152536;
        opacity: 0.7;
      }
      .body > .-info-text > .-inner-wrp > .-post-headline > .-homepage-link {
        color: #152536 !important;
      }
      .-helpful-links-header {
        margin-top: 20px;
      }
      .-helpful-links-header  ul {
        padding-left: 25px;
      }
      .-helpful-links-header-text {
        font-weight: 600;
      }
      .-helpful-link-item {
        color: #152536 !important;
      }
      .body > .-info-text > .-inner-wrp > .-details {
        font-weight: bold;
        opacity: 1;
        padding-top: 20px;
      }
      .body > .-img-wrp {
        float: left;
        display: block;
        width: 50%;
      }
      @media only screen and (max-width: 650px) {
        body .body > .-img-wrp {
          display: none;
        }
      }
      .body > .-img-wrp > .-circle {
        position: relative;
        display: block;
        margin: 0 auto;
        width: 312px;
        height: 312px;
        background-color: #d6eee2;
        -webkit-border-radius: 50%;
        -moz-border-radius: 50%;
        border-radius: 50%;
        -moz-background-clip: padding;
        -webkit-background-clip: padding-box;
        background-clip: padding-box;
      }
      .body > .-img-wrp > .-circle > .-smile-icon {
        width: 148px;
        height: 217px;
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -108.5px;
        margin-left: -74px;
      }
    </style>
  </head>
  <body>
    <div class="header">
      <div class="-logo-wrp">
        <a href="https://www.w3schools.com"
          ><svg
            width="40"
            height="38"
            viewBox="0 0 40 38"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g clip-path="url(#clip0)">
              <path
                d="M33.693 7.90419C33.693 7.90419 34.699 8.98204 36.1042 8.98204C37.2139 8.98204 38.0203 8.31138 38.0203 7.39321C38.0203 6.26746 36.9904 5.7485 35.7449 5.7485H35.0103L34.5712 4.75848L36.5193 2.4511C36.9345 1.95609 37.2858 1.64471 37.2858 1.64471C37.2858 1.64471 36.9744 1.66068 36.3437 1.66068H33.174V0L39.665 0V1.21357L37.0622 4.22355C38.5313 4.43114 39.9684 5.47705 39.9684 7.32136C39.9684 9.13373 38.5952 10.8104 36.2239 10.8104C33.9644 10.8104 32.7109 9.38922 32.7109 9.38922L33.693 7.90419Z"
                fill="#04AA6D"
              />
              <path
                d="M21.0301 10.1478L29.6049 25.4132L33.8364 17.8683L25.7406 3.45715H16.3195L12.4153 10.4112L8.5111 3.45715H0.0400391L12.3674 25.4132L12.4153 25.3334L12.4632 25.4132L21.0301 10.1478Z"
                fill="#04AA6D"
              />
              <path
                d="M0.12793 35.7604H1.38142C1.38142 36.1277 1.70078 36.479 2.26765 36.479C2.7946 36.479 3.14589 36.2155 3.14589 35.8642C3.14589 35.5608 2.91436 35.4251 2.51516 35.3372L1.79659 35.1536C0.583019 34.8342 0.271642 34.1875 0.271642 33.5009C0.271642 32.6626 1.10198 31.8961 2.27563 31.8961C3.23372 31.8961 4.31955 32.3831 4.30358 33.5808H3.03412C3.03412 33.2135 2.69879 32.9819 2.31555 32.9819C1.90038 32.9819 1.61296 33.2215 1.61296 33.5568C1.61296 33.8362 1.87643 33.9959 2.18781 34.0678L3.05009 34.2993C4.26366 34.6107 4.47923 35.3692 4.47923 35.8642C4.47923 36.958 3.38541 37.5568 2.2916 37.5568C1.22973 37.5568 0.151882 36.9101 0.12793 35.7604Z"
                fill="#04AA6D"
              />
              <path
                d="M5.58887 34.7225C5.58887 33.0139 6.96212 31.8961 8.51901 31.8961C9.45314 31.8961 10.2116 32.3113 10.7066 32.934L9.76452 33.6845C9.48507 33.3492 9.02998 33.1416 8.54296 33.1416C7.60883 33.1416 6.93817 33.8123 6.93817 34.7225C6.93817 35.6247 7.60883 36.3113 8.54296 36.3113C9.02998 36.3113 9.48507 36.1037 9.76452 35.7684L10.7066 36.5189C10.2116 37.1416 9.45314 37.5568 8.51901 37.5568C6.96212 37.5568 5.58887 36.431 5.58887 34.7225Z"
                fill="#04AA6D"
              />
              <path
                d="M17.158 34.3952V37.4132H15.8167V34.491C15.8167 33.6288 15.2977 33.1657 14.6989 33.1657C14.0842 33.1657 13.3257 33.525 13.3257 34.5709V37.4212H11.9844V29.1018H13.3337V32.8463C13.5971 32.1916 14.4674 31.8882 15.0023 31.8882C16.3916 31.8962 17.158 32.8303 17.158 34.3952Z"
                fill="#04AA6D"
              />
              <path
                d="M18.5635 34.7225C18.5635 33.0139 19.8888 31.8961 21.4218 31.8961C22.9547 31.8961 24.296 33.0139 24.296 34.7225C24.296 36.431 22.9547 37.5568 21.4218 37.5568C19.8888 37.5568 18.5635 36.431 18.5635 34.7225ZM22.9467 34.7225C22.9467 33.7963 22.2521 33.1416 21.4218 33.1416C20.5914 33.1416 19.9128 33.7963 19.9128 34.7225C19.9128 35.6646 20.5914 36.3113 21.4218 36.3113C22.2521 36.3113 22.9467 35.6646 22.9467 34.7225Z"
                fill="#04AA6D"
              />
              <path
                d="M25.4375 34.7225C25.4375 33.0139 26.7628 31.8961 28.2958 31.8961C29.8287 31.8961 31.17 33.0139 31.17 34.7225C31.17 36.431 29.8287 37.5568 28.2958 37.5568C26.7708 37.5568 25.4375 36.431 25.4375 34.7225ZM29.8207 34.7225C29.8207 33.7963 29.1261 33.1416 28.2958 33.1416C27.4654 33.1416 26.7868 33.7963 26.7868 34.7225C26.7868 35.6646 27.4654 36.3113 28.2958 36.3113C29.1341 36.3113 29.8207 35.6646 29.8207 34.7225Z"
                fill="#04AA6D"
              />
              <path
                d="M32.6553 37.4212V29.1018H33.9966V37.4212H32.6553Z"
                fill="#04AA6D"
              />
              <path
                d="M35.457 35.7604H36.7105C36.7105 36.1277 37.0299 36.479 37.5968 36.479C38.1237 36.479 38.475 36.2155 38.475 35.8642C38.475 35.5608 38.2435 35.4251 37.8443 35.3372L37.1257 35.1536C35.9121 34.8342 35.6007 34.1875 35.6007 33.5009C35.6007 32.6626 36.4311 31.8961 37.6047 31.8961C38.5628 31.8961 39.6486 32.3831 39.6327 33.5808H38.3552C38.3552 33.2135 38.0199 32.9819 37.6367 32.9819C37.2215 32.9819 36.9341 33.2215 36.9341 33.5568C36.9341 33.8362 37.1975 33.9959 37.5089 34.0678L38.3712 34.2993C39.5848 34.6107 39.8003 35.3692 39.8003 35.8642C39.8003 36.958 38.7065 37.5568 37.6127 37.5568C36.5508 37.5568 35.481 36.9101 35.457 35.7604Z"
                fill="#04AA6D"
              />
            </g>
            <defs>
              <clipPath id="clip0">
                <rect width="40" height="37.5569" fill="white" />
              </clipPath>
            </defs>
        </svg>
        </a>
      </div>
    </div>
    <div class="body">
      <div class="-info-text">
        <div class="-inner-wrp">
          <div class="-pre-headline">Sorry!</div>
          <h1 class="-headline">
            We can't seem to find the page you're looking for.
          </h1>
          <div class="-post-headline">
            Please check that the URL is correct - or go back to the
            <a id="homepage-link" href="/" class="-homepage-link">homepage</a>.
          </div>
          <div class="-post-headline -helpful-links-header">
            <span class="-helpful-links-header-text">Here are some helpful links instead:</span>
            <ul>
              <li>
                <a class="-helpful-link-item" href="https://www.w3schools.com/spaces/">Check out Spaces from W3schools</a>
              </li>
              <li>
                <a class="-helpful-link-item" href="https://www.w3schools.com/howto/howto_website_create_free.asp">Build a website with Spaces from W3schools</a>
              </li>
              <li>
                <a class="-helpful-link-item" href="https://support.w3schools.com/">Browse through support articles</a>
              </li>
            </ul>
          </div>
          <script>
            /^\/(?:|index\.html)$/i.test(window.location.pathname) &&
              (document.getElementById("homepage-link").href =
                "https://www.w3schools.com");
          </script>
        </div>
      </div>
      <div class="-img-wrp">
        <div class="-circle">
          <svg
            class="-smile-icon"
            width="142"
            height="210"
            viewBox="0 0 142 210"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M11.8136 0C11.7148 2.96327 11.8926 5.74876 12.3272 8.31693C12.7816 10.8851 13.473 13.1372 14.441 15.0337C15.409 16.9302 16.6338 18.4316 18.1155 19.5181C19.5971 20.6046 21.3553 21.1578 23.3901 21.1578C24.8322 21.1578 26.057 20.9405 27.0645 20.5256C28.0721 20.1107 29.0006 19.5774 29.8105 18.9254C30.6205 18.2735 31.4107 17.6018 32.1811 16.8907C32.9516 16.1795 33.7615 15.488 34.6308 14.8559C35.5 14.2237 36.4878 13.6706 37.594 13.2557C38.7003 12.8409 40.0634 12.6235 41.6438 12.6235C43.1847 12.6235 44.6861 12.9001 46.148 13.4335C47.6099 13.9866 48.9137 14.7768 50.0398 15.8041C51.1856 16.8511 52.0943 18.1155 52.7857 19.6366C53.4772 21.138 53.8328 22.8567 53.8328 24.7927C53.8328 27.2226 53.2796 29.3957 52.1536 31.3317C51.0473 33.2677 49.5261 34.8876 47.6297 36.231C45.7134 37.5743 43.5403 38.5818 41.0907 39.2732C38.6411 39.9646 36.0729 40.3203 33.4059 40.3203C28.803 40.3203 24.4766 39.4708 20.4071 37.7916C16.3375 36.1124 12.8013 33.6035 9.7788 30.2451C6.75626 26.9065 4.36589 22.6987 2.60768 17.6611C0.849471 12.6235 0 6.7365 0 0H11.8136ZM102.351 25.2471C102.351 27.1238 101.996 28.882 101.304 30.5217C100.613 32.1614 99.6647 33.564 98.4399 34.7493C97.2348 35.9346 95.8124 36.8829 94.1728 37.5743C92.5331 38.2657 90.7946 38.6213 88.9772 38.6213C87.1004 38.6213 85.3422 38.2657 83.7025 37.5743C82.0629 36.8829 80.6603 35.9346 79.4749 34.7493C78.2896 33.564 77.3414 32.1416 76.65 30.5217C75.9585 28.882 75.6029 27.1238 75.6029 25.2471C75.6029 23.3703 75.9388 21.6121 76.65 20.012C77.3414 18.4118 78.2896 16.9894 79.4749 15.7844C80.6603 14.5596 82.0826 13.6113 83.7025 12.9199C85.3422 12.2285 87.1004 11.8729 88.9772 11.8729C90.8144 11.8729 92.5331 12.2285 94.1728 12.9199C95.8124 13.6113 97.2348 14.5596 98.4399 15.7844C99.645 16.9894 100.613 18.4118 101.304 20.012C101.996 21.6121 102.351 23.3703 102.351 25.2471Z"
              fill="#04AA6D"
            />
            <path
              d="M59.1272 117.267H30.2255V100.554H59.1075V72.8569H74.0424V100.554H102.786V117.267H74.0424V144.963H59.1075V117.267H59.1272Z"
              fill="#04AA6D"
            />
            <path
              d="M4.22766 170.309H18.3328V192.514H127.895V170.309H142V209.227H4.22766V170.309Z"
              fill="#04AA6D"
            />
          </svg>
        </div>
      </div>
    </div>
  </body>
</html>
